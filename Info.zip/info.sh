#!/bin/bash

#==============================================================================
#
# Description: Fetches Hostname, IP, user, and outputs a jason file
#
# Usage      : ./info.sh
#
#==============================================================================

# Fetch hostname, IP, current user
host=$(hostname)
ip=$(ip route get 8.8.8.8 | grep src | sed 's/.*src \(.* \)/\1/g' | cut -f1 -d ' ')
user=$(id -u -n)

# Store the output in json file
echo "{" > output.json
echo "\"hostname\":\"$host\"," >> output.json
echo "\"ip\":$ip," >> output.json
echo "\"user\":\"$user\"" >> output.json
echo "}" >> output.json

echo "The output is stored in output.json in the current directory"

exit 0

#==== Endo of script ==========================================================
